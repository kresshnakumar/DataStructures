interface stactADT<E> {
	public void push(E element);
	public void pop();
	public int top();
	public boolean isEmpty();
}